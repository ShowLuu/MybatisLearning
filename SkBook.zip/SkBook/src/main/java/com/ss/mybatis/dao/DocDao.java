package com.ss.mybatis.dao;

public interface DocDao {
	
	public void findTwo2();

}
